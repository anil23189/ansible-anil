#Deploy properties to server
##USE AS TEMPLATE FOR NEW ROLE
