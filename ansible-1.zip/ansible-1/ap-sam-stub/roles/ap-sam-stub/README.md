ap-sam-stub
=========

role to deploy ap-sam-stub to envs

Requirements
------------


Role Variables
--------------
env - environment to deploy to (cb,sp,sit)
deploy_path - host var 
working_dir - requires {{ worskpace }} variable -e workspace=$WORKSPACE


Example Playbook
----------------
