cd "{{ base_dir }}/bin"
kill -9 $(ps -ef | grep '[a]p-sam-stub' |awk '{print $2}')
java -jar "{{ artifact_id }}-{{ component_version }}.{{ extension }}" > sam.log 2>&1 &
tail -f sam.log
