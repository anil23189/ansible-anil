adapter
=========

role to deploy adapter to cb, sprint or sit environment

Requirements
------------



Role Variables
--------------
env - environment to deploy to (cb,sp,sit)
deploy_path - host var 
working_dir - requires {{ worskpace }} variable -e workspace=$WORKSPACE


Endpoint Variables:

pos_manage_payment_endpoint_url
pos_manage_advice_endpoint_url
pos_manage_refund_endpoint_url
pos_health_check_service_endpoint_url
mdm_health_check_service_endpoint_url
pos_manage_exception_endpoint_url
mdm_referencedata_service_endpoint_url

Adapter properties Variables:

server_host
port
network_group_id
mastercard_customer_id

Default:

connection_time_out
retry_interval_time
sign_on_response_timeout

networt_security_password
link_activation_required
mip_probe_interval




Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - { role: username.rolename, x: 42 }

